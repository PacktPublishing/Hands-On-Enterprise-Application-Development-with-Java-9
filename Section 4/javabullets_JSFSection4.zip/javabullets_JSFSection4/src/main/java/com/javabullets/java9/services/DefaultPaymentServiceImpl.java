package com.javabullets.java9.services;

import javax.inject.Named;

@Named("defaultPayment")
public class DefaultPaymentServiceImpl implements PaymentService {
}
