package com.javabullets.java9.entity;

import java.io.Serializable;

public enum Sex implements Serializable {
	MALE, FEMALE;
}