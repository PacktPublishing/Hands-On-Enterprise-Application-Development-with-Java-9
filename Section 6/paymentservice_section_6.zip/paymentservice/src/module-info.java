module com.javabullets.module.ps {
	exports com.javabullets.payment.internal to com.javabullets.pc;
	exports com.javabullets.payment.external;
}